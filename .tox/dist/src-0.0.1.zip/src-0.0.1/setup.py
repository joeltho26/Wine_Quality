from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="its a wineQ package",
    author="joeltho",
    packages=find_packages(),
    license="MIT"
)
